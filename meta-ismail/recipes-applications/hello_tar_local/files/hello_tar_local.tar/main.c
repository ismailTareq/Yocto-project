#include <stdio.h>

int main() {
    printf("Hello, CMake {tar local bitch} \n", value);
    return 0;
}